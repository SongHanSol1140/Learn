package com.example.hellospringapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HellospringapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(HellospringapiApplication.class, args);
	}

}
