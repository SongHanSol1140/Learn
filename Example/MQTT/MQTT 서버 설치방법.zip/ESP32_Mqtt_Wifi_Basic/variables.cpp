#include "variables.h"

// 와이파이 정보
char wifi_ssid[] = "NNX2-2.4G";
char wifi_password[] = "$@43skshslrtm";
IPAddress wifiIP(192, 168, 0, 233);  // 고정 IP 주소
IPAddress gateway(192, 168, 0, 1);     // 게이트웨이 주소
IPAddress subnet(255, 255, 255, 0);    // 서브넷 마스크

// MQTT 정보
char mqttClientName[] = "ESP32_MqttTestSubscriber";
char mqttUserName[] = "nanonix";
char mqttPassword[] = "$@43nanonix";
char topic[] = "DoorSystem";
IPAddress mqttAddress(192, 168, 0, 19);  // MQTT 브로커 IP
