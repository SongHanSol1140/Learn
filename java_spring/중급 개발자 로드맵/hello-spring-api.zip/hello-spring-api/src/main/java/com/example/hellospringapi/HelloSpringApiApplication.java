package com.example.hellospringapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloSpringApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloSpringApiApplication.class, args);
	}

}
