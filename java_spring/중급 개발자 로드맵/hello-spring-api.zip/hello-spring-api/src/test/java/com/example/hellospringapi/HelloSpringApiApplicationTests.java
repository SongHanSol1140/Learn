package com.example.hellospringapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloSpringApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
